<?php
include 'connect.php';
include 'connect2.php';

 if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];

    $sql="insert into `signup` (name, email, password) 
    values('$name', '$email', '$password')";
    $result = mysqli_query($con,$sql);
    if($result)
    {
        echo "data is inserted successfully";
    } 
    else{
        die(mysqli_error($con));
    }
}

 if(isset($_POST['signin'])){
    $email=$_POST['nemail'];
    $password=$_POST['npassword'];

    $sql2="insert into `signin` (email, password) 
    values('$email', '$password')";
    $result2 = mysqli_query($con2,$sql2);
    if($result2)
    {
        echo "data is inserted successfully";
    } 
    else{
        die(mysqli_error($con2));
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./bootstrap/bootstrap.css">
    <link rel="stylesheet" href="./css/the.css">
    <script src="https://kit.fontawesome.com/271c6fe27f.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>running task</title>
</head>
<body>
    <div class="container" id="container">
        <div class="form-container sign-up-container">

            <form method="post">
                <h1>Create Account</h1>
                <div class="social-container">
                    <a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social"><i class="fab fa-google-plus-g"></i></a>
                    <a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
                </div>
                <span>or use your email for registration</span>
                
                    <input type="text" class="form-control" name="name" placeholder="Name" />
                    <input type="email" class="form-control" name="email" placeholder="Email" />
                    <input type="password" class="form-control" name="password" placeholder="Password" />
                    <button type="submit" name="submit">Sign Up</button>
            </form>
        </div>
        <div class="form-container sign-in-container">
            <form method="post">
                <h1>Sign in</h1>
                <div class="social-container">
                    <a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social"><i class="fab fa-google-plus-g"></i></a>
                    <a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
                </div>
                <span>or use your account</span>
                
                    <input type="email" name="nemail" class="form-control" placeholder="Email" />
                    <input type="password" name="npassword" class="form-control"  placeholder="Password" />
                    <a href="#">Forgot your password?</a>
                    <button type="submit" name="signin">Sign In</button>
               
            </form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <h1>Welcome Back!</h1>
                    <p>To keep connected with us please login with your personal info</p>
                    <button class="ghost" id="signIn">Sign In</button>
                </div>
                <div class="overlay-panel overlay-right">
                    <h1>Hello, Friend!</h1>
                    <p>Enter your personal details and start journey with us</p>
                    <button class="ghost" id="signUp">Sign Up</button>
                </div>
            </div>
        </div>
    </div>
    <script src = "./js/the.js"></script>

    
</body>  
</html>