<?php

$con2 = new mysqli('localhost', 'root', '','crudoperation');

if(!$con2)
{
    die(mysqli_error($con2));
}
?>